﻿using LetsLearn.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LetsLearn.Repos
{
    public class ExerciceRepository : Repository
    {
        public ExerciceRepository(ManagementContext teacherContext) : base(teacherContext)
        {

        }
    }
}
